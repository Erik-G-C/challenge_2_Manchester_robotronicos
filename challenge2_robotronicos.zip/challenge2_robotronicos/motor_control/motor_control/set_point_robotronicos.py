import rclpy
from rclpy.node import Node
import numpy as np
from std_msgs.msg import Float32
from rcl_interfaces.msg import SetParametersResult

class SetPointPublisher(Node):
    def __init__(self):
        super().__init__('set_point_robotronicos')

        # Parámetros del setpoint
        self.declare_parameter('signal_type', 'sine')  # Puede ser 'sine', 'square' o 'constant'
        self.declare_parameter('amplitude', 2.0)
        self.declare_parameter('frequency', 1.0)
        self.declare_parameter('setpoint_value', 5.0)  # Solo se usa si es constante
        self.timer_period = 0.1


        #self.signal_type = self.get_parameter('signal_type').value
        #self.amplitude = self.get_parameter('amplitude').value
        #self.omega = 2 * np.pi * self.get_parameter('frequency').value
        #self.setpoint_value = self.get_parameter('setpoint_value').value

        # Publicador de la señal
        self.signal_publisher = self.create_publisher(Float32, '/set_point_robotronicos', 10)
        self.timer = self.create_timer(self.timer_period, self.timer_cb)

        self.signal_msg = Float32()
        self.start_time = self.get_clock().now()

    def timer_cb(self):
        elapsed_time = (self.get_clock().now() - self.start_time).nanoseconds / 1e9
        if self.signal_type == 'sine':
            self.signal_msg.data = self.amplitude * np.sin(self.omega * elapsed_time)
        elif self.signal_type == 'square':
            self.signal_msg.data = self.amplitude if np.sin(self.omega * elapsed_time) >= 0 else -self.amplitude
        elif self.signal_type == 'constant':
            self.signal_msg.data = self.setpoint_value
        self.signal_publisher.publish(self.signal_msg)


def main(args=None):
    rclpy.init(args=args)

    set_point = SetPointPublisher()

    try:
        rclpy.spin(set_point)
    except KeyboardInterrupt:
        pass
    finally:
        set_point.destroy_node()
        rclpy.try_shutdown()

if __name__ == '__main__':
    main()