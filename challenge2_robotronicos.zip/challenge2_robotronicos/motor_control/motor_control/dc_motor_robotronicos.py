import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from rcl_interfaces.msg import SetParametersResult

class DCMotor(Node):
    def __init__(self):
        super().__init__('dc_motor_robotronicos')

        # Parámetros del motor
        self.declare_parameter('sample_time', 0.01)
        self.declare_parameter('sys_gain_K', 2.16)
        self.declare_parameter('sys_tau_T', 0.05)
        self.declare_parameter('initial_conditions', 0.0)

        self.sample_time = self.get_parameter('sample_time').value
        self.param_K = self.get_parameter('sys_gain_K').value
        self.param_T = self.get_parameter('sys_tau_T').value
        self.output_y = self.get_parameter('initial_conditions').value

        # Publicación y suscripción
        self.motor_input_sub = self.create_subscription(Float32, '/motor_input_u_robotronicos', self.input_callback, 10)
        self.motor_speed_pub = self.create_publisher(Float32, '/motor_speed_y_robotronicos', 10)
        self.timer = self.create_timer(self.sample_time, self.timer_cb)
        self.add_on_set_parameters_callback(self.parameters_callback)

        # Mandar mensajes
        self.motor_msg = Float32()

    def timer_cb(self):
        #DC Motor Simulation
        #DC Motor Equation 𝑦[𝑘+1] = 𝑦[𝑘] + ((−1/𝜏) 𝑦[𝑘] + (𝐾/𝜏) 𝑢[𝑘]) 𝑇_𝑠
        self.output_y += (-1.0 / self.param_T * self.output_y + self.param_K / self.param_T * self.input_u) * self.sample_time
        self.motor_msg.data = self.output_y
        self.motor_speed_pub.publish(self.motor_msg)

    def input_callback(self, msg):
        self.input_u = msg.data

    def parameters_callback(self, params):
        for param in params:
            #system gain parameter check
            if param.name == "sys_gain_K":
                #check if it is negative
                if (param.value < 0.0):
                    self.get_logger().warn("Invalid sys_gain_K! It cannot be negative.")
                    return SetParametersResult(successful=False, reason="sys_gain_K cannot be negative")
                else:
                    self.param_K = param.value  # Update internal variable
                    self.get_logger().info(f"sys_gain_K updated to {self.param_K}")
                
            #system gain parameter check
            if param.name == "sys_tau_T":
                #check if it is negative
                if (param.value < 0.0):
                    self.get_logger().warn("Invalid sys_tau_T! It cannot be negative.")
                    return SetParametersResult(successful=False, reason="sys_tau_T cannot be negative")
                else:
                    self.param_T = param.value  # Update internal variable
                    self.get_logger().info(f"sys_tau_T updated to {self.param_T}")

        return SetParametersResult(successful=True)


def main(args=None):
    rclpy.init(args=args)
    node = DCMotor()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()