import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np
from rcl_interfaces.msg import SetParametersResult

class PIDController(Node):
    def __init__(self):
        super().__init__('controller_robotronicos')

        # Parámetros del PID
        self.declare_parameter('kp', 1.0)
        self.declare_parameter('ki', 0.1)
        self.declare_parameter('kd', 0.01)
        self.declare_parameter('dt', 0.01)

        self.kp = self.get_parameter('kp').value
        self.ki = self.get_parameter('ki').value
        self.kd = self.get_parameter('kd').value
        self.dt = self.get_parameter('dt').value

        # Suscripciones y Publicaciones
        self.subscription_setpoint = self.create_subscription(Float32, '/set_point_robotronicos', self.setpoint_callback, 10)
        self.subscription_output = self.create_subscription(Float32, '/motor_speed_y_robotronicos', self.output_callback, 10)
        self.publisher = self.create_publisher(Float32, '/motor_input_u_robotronicos', 10)

        self.add_on_set_parameters_callback(self.parameters_callback)

        # Variables PID
        self.setpoint = 0.0
        self.output = 0.0
        self.integral = 0.0
        self.prev_error = 0.0
        self.anterior = 0.0

        # Timer para control en tiempo real
        self.timer = self.create_timer(self.dt, self.timer_callback)

    def setpoint_callback(self, msg):
        self.setpoint = msg.data

    def output_callback(self, msg):
        self.output = msg.data

    def timer_callback(self):
        error = self.setpoint - self.output
        self.integral += error * self.dt
        self.integral = np.clip(self.integral, -6, 6)

        proportional = self.kp * self.prev_error
        integrative = self.ki*self.integral
        derivative = self.kd * ((self.prev_error - self.anterior) / self.dt)

        control_signal = proportional * integrative + derivative

        self.anterior = self.prev_error

        msg = Float32()
        msg.data = control_signal
        self.publisher.publish(msg)

        self.motor_msg = Float32()

        self.motor_msg.data = msg.data
        self.publisher.publish(self.motor_msg)

    def parameters_callback(self, params):
        for param in params:
            if param.name == "gain_Kp":
                if param.value < 0.0:
                    return SetParametersResult(successful=False, reason="gain_Kp cannot be negative")
                self.gain_Kp = param.value
                self.get_logger().info(f"gain_Kp updated to {self.gain_Kp}")

            if param.name == "gain_Ki":
                if param.value < 0.0:
                    return SetParametersResult(successful=False, reason="gain_Ki cannot be negative")
                self.gain_Ki = param.value
                self.get_logger().info(f"gain_Ki updated to {self.gain_Ki}")

            if param.name == "gain_Kd":
                if param.value < 0.0:
                    return SetParametersResult(successful=False, reason="gain_Kd cannot be negative")
                self.gain_Kd = param.value
                self.get_logger().info(f"gain_Kd updated to {self.gain_Kd}")

            if param.name == "sample_time":
                if param.value <= 0.0:
                    return SetParametersResult(successful=False, reason="sample_time must be positive")
                self.sample_time = param.value
                self.get_logger().info(f"sample_time updated to {self.sample_time}")
                
                # Reiniciar el temporizador con el nuevo sample_time
                self.timer.cancel()
                self.timer = self.create_timer(self.sample_time, self.timer_cb)

        return SetParametersResult(successful=True)


def main(args=None):
    rclpy.init(args=args)
    node = PIDController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()