from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # Nodo del sistema del motor simulado
    motor_node = Node(
        name="dc_motor_robotronicos",
        package="motor_control",
        executable="dc_motor",
        output="screen",
        parameters=[{
            "sample_time": 0.01,
            "sys_gain_K": 2.16,
            "sys_tau_T": 0.05,
            "initial_conditions": 0.0,
        }]
    )

    # Nodo generador de setpoints
    sp_node = Node(
        name="set_point_robotronicos",
        package="motor_control",
        executable="set_point",
        output="screen",
        parameters=[{
            "signal_type": "sine",
            "amplitude": 2.0,
            "frequency": 1.0,
            "setpoint_value": 5.0,
        }]
    )

    # Nodo del controlador PID
    controller = Node(
        name="controller_robotronicos",
        package="motor_control",
        executable="controller",
        output="screen",
        parameters=[{
            "kp": 1.0,
            "ki": 0.1,
            "kd": 0.01,
        }]
    )

    # RQT Plot para visualizar la respuesta del sistema
    rqt_plot_node = Node(
        package="rqt_plot",
        executable="rqt_plot",
        arguments=["/set_point_robotronicos", "/motor_speed_y_robotronicos", "/motor_input_u_robotronicos"],
        output="screen"
    )

    # RQT Graph para ver la conexión entre nodos
    rqt_graph_node = Node(
        package="rqt_graph",
        executable="rqt_graph",
        output="screen"
    )

    return LaunchDescription([
        motor_node,
        sp_node,
        controller,
        rqt_plot_node,
        rqt_graph_node
    ])